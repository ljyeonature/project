import React from 'react';
import '../style/footer.css'

const Footer = () => {
	return (
		<footer id="contact">
		  <h2>CONTACT</h2>
		  <div className="contacts">
			<div className="contacts__email">
			  <h3>MAIL</h3>
			  <p>sam5834@naver.com</p>
			</div>
			<div className="contacts__phone">
			  <h3>PHONE</h3>
			  <p>010-2823-5834</p>
			</div>
			{/* <div className="contacts__sns">
			  <h3>SNS</h3>
			  <p>@insta_</p>
			</div> */}
			<div className="contacts__blog">
			  <h3>BLOG</h3>
			  <p><a href="https://naturepublic.tistory.com/">블로그로 이동!</a></p>
			</div>
		  </div>
		  <p style={{textAlign:'center'}}>Copyright &copy; jiyeon. All Right Reserved.</p>
	  	</footer>
	  )
};

export default Footer;