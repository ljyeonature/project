import React from 'react';
import '../style/header.css'

const Main = () => {
	return (
	  <div className="main">
		
		<h1 className="main__headline">
		  Hello!
		</h1>
		<h1 className="main__headline">
		  Welcome to JiYeon's Portfolio
		</h1>
	 </div>
	)
  }

  export default Main;