import React, {useEffect} from 'react';
import WOW from 'wowjs'
import '../style/portfolio.css'
import '../style/skills.css'
import '../style/about.css'

const Section = () => {
	useEffect( () => {
		new WOW.WOW().init();
	}, []);
	return (
		<section>
			<article id="about" >
				<h2>ABOUT JiYeon</h2>
				<ul className="about">
					<li className="about__photo">
						<img src="" alt="프로필 사진" />
					</li>
					<li className="about__introduction">
					<h3 className="category">PROFILE</h3>
					<p>
					...
					</p>
					</li>
				</ul>
			</article>
			<article id="skills" >
			<h2>SKILLS</h2>
			<div className="skills">
				<div className="skill">
					<h2 className="wow bounce" >HTML</h2>
					<p>스킬을 사용해 할 수 있는 것들 대강 묘사</p>
				</div>
				<div className="skill">
					<h2 className="wow bounce" >CSS</h2>
					<p>스킬을 사용해 할 수 있는 것들 대강 묘사</p>
				</div>
				<div className="skill">
					<h2 className="wow bounce">Javascript</h2>
					<p>스킬을 사용해 할 수 있는 것들 대강 묘사</p>
				</div>
				<div className="skill">
					<h2 className="wow bounce">Jquery</h2>
					<p>스킬을 사용해 할 수 있는 것들 대강 묘사</p>
				</div>
				<div className="skill">
					<h2 className="wow bounce">React</h2>
					<p>스킬을 사용해 할 수 있는 것들 대강 묘사</p>
				</div>
				</div>
			</article>
			<article id="port">
				<h2>PORTFOLIO</h2>
				<button className="prev" onClick="prev()">
				<i className="fa-5x fas fa-angle-left"></i>
				</button>
				<div className="single-items">
				<div className="item active">one</div>
				<div className="item">two</div>
				<div className="item">three</div>
				<div className="item">four</div>
				</div>
				<ul className="stepper">
				<li className="step active-step"><i className="fas fa-circle"></i></li>
				<li className="step"><i className="fas fa-circle"></i></li>
				<li className="step"><i className="fas fa-circle"></i></li>
				<li className="step"><i className="fas fa-circle"></i></li>
				</ul>
				<button className="next" onClick="next()">
				<i className="fa-5x fas fa-angle-right"></i>
				</button>
			</article>
			
		</section>
	  )
};

export default Section;